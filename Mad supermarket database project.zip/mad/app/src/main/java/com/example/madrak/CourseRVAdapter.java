package com.example.madrak;


import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Currency;

public class CourseRVAdapter extends RecyclerView.Adapter<CourseRVAdapter.ViewHolder> {

    // variable for our array list and context
    private ArrayList<SupermarketModel> itemModelArrayList;
    private Context context;

    // constructor
    public CourseRVAdapter(ArrayList<SupermarketModel> itemModelArrayList, Context context) {
        this.itemModelArrayList = itemModelArrayList;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // on below line we are inflating our layout
        // file for our recycler view items.
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.course_rv_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        // on below line we are setting data
        // to our views of recycler view item.
        Log.i("TAG", "onBindViewHolder: "+itemModelArrayList.get(position).getitemName()+" "+itemModelArrayList.get(position).getitemPrice()+" "+itemModelArrayList.get(position).getitemQuantity()+" "+itemModelArrayList.get(position).getitemCat());
        SupermarketModel modal = itemModelArrayList.get(position);
        holder.itemName.setText("Name: "+modal.getitemName());
        holder.itemPrice.setText("Price: "+ Currency.getInstance("INR").getSymbol()+modal.getitemQuantity());
        holder.quantity.setText("Quantity :"+modal.getitemCat());
        holder.category.setText("Category: "+modal.getitemPrice());
    }

    @Override
    public int getItemCount() {
        // returning the size of our array list
        return itemModelArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        // creating variables for our text views.
        private TextView itemName, category, quantity, itemPrice;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            // initializing our text views
            itemName = itemView.findViewById(R.id.idTVItemName);
            category = itemView.findViewById(R.id.itTVCategory);
            quantity = itemView.findViewById(R.id.idTVQuantity);
            itemPrice = itemView.findViewById(R.id.idTVItemPrice);
        }
    }
}


